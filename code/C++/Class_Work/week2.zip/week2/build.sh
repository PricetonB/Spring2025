g++ assignment2.cpp -o assignment2
