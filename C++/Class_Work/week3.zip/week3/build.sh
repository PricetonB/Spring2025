g++ assignment3.cpp -o assignment3
